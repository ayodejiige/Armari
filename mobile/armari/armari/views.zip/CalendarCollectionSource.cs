﻿using System;
using Foundation;
using UIKit;
using System.Collections.Generic;


namespace armari
{
    public class CalendarCollectionSource : UICollectionViewDataSource
    {
        #region Computed Properties
        private readonly int MAX_CELLS = 4;
        public CalendarCollectionView CollectionView { get; set; }
        public List<int> Numbers { get; set; } = new List<int>();
        public List<string> ImagePaths { get; set; } = new List<string>();
        private readonly DateHandler CalendarDateHandler = new DateHandler();
        private List<string> Days { get; set; }
        #endregion

        #region Constructors
        public CalendarCollectionSource(CalendarCollectionView collectionView)
        {
            // Initialize
            CollectionView = collectionView;

            Days = CalendarDateHandler.GetListOfDays(MAX_CELLS);

            ImagePaths.Add("outfitCollection_1.png");
            ImagePaths.Add("outfitCollection_2.png");
            ImagePaths.Add("item_5.png");
            ImagePaths.Add("outfitIcon_1.png");

            // Init numbers collection
            for (int n = 0; n < MAX_CELLS; ++n)
            {
                Numbers.Add(n);
            }
        }
        #endregion

        #region Override Methods
        public override nint NumberOfSections(UICollectionView collectionView)
        {
            // We only have one section
            return 1;
        }

        public override nint GetItemsCount(UICollectionView collectionView, nint section)
        {
            // Return the number of items
            return Numbers.Count;
        }

        public override UICollectionViewCell GetCell(UICollectionView collectionView, NSIndexPath indexPath)
        {
            // Get a reusable cell and set {~~it's~>its~~} title from the item
            var cell = collectionView.DequeueReusableCell("Cell", indexPath) as CalendarCollectionViewCell;
            //cell.Title = Numbers[(int)indexPath.Item].ToString();
            cell.Title = Days[(int)indexPath.Item];
            cell.CellImage.Image = UIImage.FromBundle(ImagePaths[(int)indexPath.Item]);
            cell.CellImage.Layer.BorderWidth = 1;
            //cell.CellImage.Layer.CornerRadius = 20;
            cell.CellImage.Layer.MasksToBounds = true;

            return cell;
        }

        public override bool CanMoveItem(UICollectionView collectionView, NSIndexPath indexPath)
        {
            // We can always move items
            return true;
        }

        public override void MoveItem(UICollectionView collectionView, NSIndexPath sourceIndexPath, NSIndexPath destinationIndexPath)
        {
            // Reorder our list of items
            var item = Numbers[(int)sourceIndexPath.Item];
            Numbers.RemoveAt((int)sourceIndexPath.Item);
            Numbers.Insert((int)destinationIndexPath.Item, item);
        }
        #endregion
    }
}