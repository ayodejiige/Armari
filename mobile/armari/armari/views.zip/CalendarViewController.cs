﻿using System;

using System.Collections;
using System.Collections.Generic;
using System.Windows.Input;
using UIKit;

using Xamarin.Forms;

namespace armari
{

    public partial class CalendarViewController : UIViewController
    {
        public CalendarViewController() : base("CalendarViewController", null)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }


}

